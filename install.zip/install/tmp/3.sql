/**
 * This script performs all the table alterations needed to run the Optigrid
 * software on top of it.
 *
 */


/*
 * TABLE: event_log
 */

ALTER TABLE event_log ADD CONSTRAINT event_type_lookup_event_log
    FOREIGN KEY (event_type_id)
    REFERENCES event_type_lookup(event_type_id)
    ;

/*
 * TABLE: host_pages_acl
 */

ALTER TABLE host_pages_acl ADD CONSTRAINT host_pageshost_pages_acl
    FOREIGN KEY (page_id)
    REFERENCES host_pages(page_id)
    ;

ALTER TABLE host_pages_acl ADD CONSTRAINT user_groupshost_pages_acl
    FOREIGN KEY (group_id)
    REFERENCES user_groups(group_id)
    ;

/*
 * TABLE: link
 */

ALTER TABLE link ADD CONSTRAINT portlink
    FOREIGN KEY (clear_port_id)
    REFERENCES port(port_id)
    ;

ALTER TABLE link ADD CONSTRAINT portlink1
    FOREIGN KEY (secure_port_id)
    REFERENCES port(port_id)
    ;

/*
 * TABLE: location
 */

ALTER TABLE location MODIFY 
    location_id int DEFAULT %COS '$i(^SYSAutoIncrement("ISA.location","location_id"))'
;

/*
 * TABLE: port
 */

ALTER TABLE port ADD CONSTRAINT baudrate_lookupport
    FOREIGN KEY (baudrate)
    REFERENCES baudrate_lookup(baudrate)
    ;

ALTER TABLE port ADD CONSTRAINT parity_lookupport
    FOREIGN KEY (parity_id)
    REFERENCES parity_lookup(parity_id)
    ;

/*
 * TABLE: rmd_line
 */

ALTER TABLE rmd_line ADD CONSTRAINT baudrate_lookuprmd_line
    FOREIGN KEY (ctl_baudrate)
    REFERENCES baudrate_lookup(baudrate)
    ;

ALTER TABLE rmd_line ADD CONSTRAINT baudrate_lookuprmd_line1
    FOREIGN KEY (modem_baudrate)
    REFERENCES baudrate_lookup(baudrate)
    ;

ALTER TABLE rmd_line ADD CONSTRAINT parity_lookuprmd_line
    FOREIGN KEY (ctl_parity_id)
    REFERENCES parity_lookup(parity_id)
    ;

ALTER TABLE rmd_line ADD CONSTRAINT parity_lookuprmd_line1
    FOREIGN KEY (modem_parity_id)
    REFERENCES parity_lookup(parity_id)
    ;

ALTER TABLE rmd_line ADD CONSTRAINT rsmrmd_line
    FOREIGN KEY (rsm_id)
    REFERENCES rsm(rsm_id)
    ;

/*
 * TABLE: rmd_schedule
 */

ALTER TABLE rmd_schedule ADD CONSTRAINT rmd_schedule_rsm_id
	FOREIGN KEY (rsm_id)
	REFERENCES rsm(rsm_id)
	;

/*
 * TABLE: rsm
 */

ALTER TABLE rsm ADD CONSTRAINT linkrsm
    FOREIGN KEY (link_id)
    REFERENCES link(link_id)
    ;

ALTER TABLE rsm ADD CONSTRAINT locationrsm
    FOREIGN KEY (location_id)
    REFERENCES location(location_id)
    ;

/*
 * TABLE: sys_default
 */

ALTER TABLE sys_default ADD CONSTRAINT baudrate_lookupsys_default
    FOREIGN KEY (baudrate)
    REFERENCES baudrate_lookup(baudrate)
    ;

ALTER TABLE sys_default ADD CONSTRAINT parity_lookupsys_default
    FOREIGN KEY (parity_id)
    REFERENCES parity_lookup(parity_id)
    ;

/*
 * TABLE: users_user_group_rel
 */

ALTER TABLE users_user_group_rel ADD CONSTRAINT user_groupsusers_user_group_rel
    FOREIGN KEY (group_id)
    REFERENCES user_groups(group_id)
    ;

ALTER TABLE users_user_group_rel ADD CONSTRAINT usersusers_user_group_rel
    FOREIGN KEY (user_id)
    REFERENCES users(user_id)
    ;

/**
 * This script creates all the database indexes we need to run the Optigrid
 * software.
 *
 */

/*
 * INDEX: baudrate_lookup_baudrate_id_idx
 */

CREATE UNIQUE INDEX baudrate_lookup_baudrate_id_idx ON baudrate_lookup(baudrate);

/*
 * INDEX: command_queue_command_id_idx
 */

CREATE UNIQUE INDEX command_queue_command_id_idx ON command_queue(command_id);

/*
 * INDEX: command_queue_command_ts_idx
 */

CREATE INDEX command_queue_command_ts_idx ON command_queue(response_ts);

/*
 * INDEX: command_queue_host_id_idx
 */

CREATE INDEX command_queue_host_id_idx ON command_queue(host_id);

/*
 * INDEX: command_queue_link_id_idx
 */

CREATE INDEX command_queue_link_id_idx ON command_queue(link_id);


/*
 * INDEX: command_queue_request_ts_idx
 */

CREATE INDEX command_queue_request_ts_idx ON command_queue(command_ts);

/*
 * INDEX: command_queue_status_idx
 */

CREATE INDEX command_queue_status_idx ON command_queue(status);

/*
 * INDEX: data_capture_link_id_idx
 */

CREATE INDEX data_capture_link_id_idx ON data_capture(link_id);

/*
 * INDEX: data_capture_session_id_idx
 */

CREATE UNIQUE INDEX data_capture_session_id_idx ON data_capture(data_capture_id);

/*
 * INDEX: data_capture_start_ts_idx
 */

CREATE INDEX data_capture_start_ts_idx ON data_capture(start_ts);

/*
 * INDEX: data_capture_end_ts_idx
 */

CREATE INDEX data_capture_end_ts_idx ON data_capture(end_ts);

/*
 * INDEX: data_log_capture_id_idx
 */

CREATE INDEX data_log_capture_id_idx ON data_log(data_capture_id);

/*
 * INDEX: data_log_id_idx
 */

CREATE INDEX data_log_id_idx ON data_log(data_log_id);

/*
 * INDEX: data_log_end_ts_idx
 */

CREATE INDEX data_log_end_ts_idx ON data_log(end_ts);

/*
 * INDEX: data_log_start_ts_idx
 */

CREATE INDEX data_log_start_ts_idx ON data_log(start_ts);

/*
 * INDEX: event_log_category_idx
 */

CREATE INDEX event_log_category_idx ON event_log(event_type_id);

/*
 * INDEX: event_log_datetime_ts_idx
 */

CREATE INDEX event_log_datetime_ts_idx ON event_log(datetime_ts);

/*
 * INDEX: event_log_event_id_idx
 */

CREATE UNIQUE INDEX event_log_event_log_id_idx ON event_log(event_id);

/*
 * INDEX: event_log_host_id_idx
 */

CREATE INDEX event_log_host_id_idx ON event_log(host_id);

/*
 * INDEX: event_log_severity_idx
 */

CREATE INDEX event_log_severity_idx ON event_log(severity);

/*
 * INDEX: event_log_user_id_idx
 */

CREATE INDEX event_log_user_id_idx ON event_log(user_id);

/*
 * INDEX: event_log_command_id_idx
 */

CREATE INDEX event_log_command_id_idx ON event_log(command_id);

/*
 * INDEX: event_type_lookup_event_type_id_idx
 */

CREATE UNIQUE INDEX event_type_lookup_event_type_id_idx ON event_type_lookup(event_type_id);

/*
 * INDEX: event_type_lookup_name_idx
 */

CREATE UNIQUE INDEX event_type_lookup_name_idx ON event_type_lookup(name);

/*
 * INDEX: host_hist_id_idx
 */

CREATE UNIQUE INDEX host_hist_id_idx ON host(host_id);

/*
 * INDEX: page_id
 */

CREATE INDEX host_pages_page_id ON host_pages(page_id);

/*
 * INDEX: acl_id
 */

CREATE INDEX host_pages_acl_id ON host_pages_acl(host_page_acl_id);

/*
 * INDEX: host_param_host_id_idx
 */

CREATE INDEX host_param_host_id_idx ON host_parameters(host_id);

/*
 * INDEX: host_param_param_name_idx
 */

CREATE INDEX host_param_param_name_idx ON host_parameters(param_name);

/*
 * INDEX: link_clear_port_id_idx
 */

CREATE INDEX link_clear_port_id_idx ON link(clear_port_id);

/*
 * INDEX: link_secure_port_id_idx
 */

CREATE INDEX link_secure_port_id_idx ON link(secure_port_id);

/*
 * INDEX: location_location_id_idx
 */

CREATE UNIQUE INDEX location_location_id_idx ON location(location_id);

/*
 * INDEX: parity_lookup_parity_id_idx
 */

CREATE UNIQUE INDEX parity_lookup_parity_id_idx ON parity_lookup(parity_id);

/*
 * INDEX: port_host_id_idx
 */

CREATE INDEX port_host_id_idx ON port(host_id);

/*
 * INDEX: port_port_id_idx
 */

CREATE INDEX port_port_id_idx ON port(port_id);

/*
 * INDEX: rmd_line_line_number_idx
 */

CREATE INDEX rmd_line_line_number_idx ON rmd_line(line_number);

/*
 * INDEX: rmd_line_rsm_id_idx
 */

CREATE INDEX rmd_line_rsm_id_idx ON rmd_line(rsm_id);

/*
 * INDEX: rmd_schedule_rsm_id_idx
 */
CREATE INDEX rmd_schedule_rsm_id_idx ON rmd_schedule(rsm_id);

/*
 * INDEX: rmd_schedule_line_number_idx
 */
CREATE INDEX rmd_schedule_line_number_idx ON rmd_schedule(line_number);

/*
 * INDEX: rsm_link_id_idx
 */

CREATE INDEX rsm_link_id_idx ON rsm(link_id);

/*
 * INDEX: rsm_rsm_id_idx
 */

CREATE UNIQUE INDEX rsm_rsm_id_idx ON rsm(rsm_id);

/*
 * INDEX: sys_compression_id_idx
 */

CREATE UNIQUE INDEX sys_compression_id_idx ON sys_compression(id);

/*
 * INDEX: sys_default_id_idx
 */

CREATE INDEX sys_default_id_idx ON sys_default(id);

/*
 * INDEX: sys_security_id_idx
 */

CREATE UNIQUE INDEX sys_security_id_idx ON sys_security(host_id);

/*
 * INDEX: user_groups_group_name_idx
 */

CREATE INDEX user_groups_group_name_idx ON user_groups(name);

/*
 * INDEX: user_groups_user_group_id_idx
 */

CREATE INDEX user_groups_user_group_id_idx ON user_groups(group_id);

/*
 * INDEX: users_user_group_rel_user_group_id_idx
 */

CREATE INDEX users_user_group_rel_user_group_id_idx ON users_user_group_rel(group_id);

/*
 * INDEX: users_user_group_rel_user_id_idx
 */

CREATE INDEX users_user_group_rel_user_id_idx ON users_user_group_rel(user_id);

/*
 * INDEX: users_PassHash_idx
 */

CREATE INDEX users_PassHash_idx ON users(password);

/*
 * INDEX: users_user_id_idx
 */

CREATE INDEX users_user_id_idx ON users(user_id);

/*
 * INDEX: user_login_idx
 */

CREATE INDEX user_login_idx ON users(login);
