/**
 * This script creates all the database tables we need to run the Optigrid
 * software.
 *
 */

/*
 * TABLE: baudrate_lookup
 */

CREATE TABLE baudrate_lookup(
    baudrate    int    NOT NULL,
    CONSTRAINT PK_baudrate_lookup PRIMARY KEY (baudrate)
)
;


/*
 * TABLE: isa_firmware
 *
 * Peter Schneider 		February 28, 2007   Created.
 */

CREATE TABLE isa_firmware(
    firmware_id          int             AUTO_INCREMENT,
    creation_ts          TIMESTAMP       DEFAULT CURRENT_TIMESTAMP NOT NULL,
    file_ver             smallint        NOT NULL,
    company              varchar(10)     NOT NULL,
    comp                 TINYINT         DEFAULT 0 NOT NULL,
    device_module        SMALLINT        NOT NULL,
    maj_ver              SMALLINT        NOT NULL,
    min_ver              SMALLINT        NOT NULL,
    pat_ver              SMALLINT        NOT NULL,
    cont_chunks          TINYINT         NOT NULL,
    firmware             LONGBLOB        NULL,
    CONSTRAINT PK_isa_firmware PRIMARY KEY (firmware_id)
)
;

/*
 * TABLE: command_queue
 *
 * Peter Schneider 		December 12, 2005   Removed: response_type, response_event_id, response_user_msg
 *                                          as not being used anymore.
 *											Added: status value of 'F' for Failed.
 */

CREATE TABLE command_queue(
	command_id	int		AUTO_INCREMENT,
    status               varchar(1)      NOT NULL,
    host_id              smallint        NOT NULL,
    link_id              int             NOT NULL,
    user_id              int             NOT NULL,
    command_ts           TIMESTAMP       DEFAULT CURRENT_TIMESTAMP NOT NULL,
    command_type         smallint        DEFAULT 0 NOT NULL,
    command_params       varchar (255)   NULL,
    response_ts          TIMESTAMP       NULL, /*DEFAULT CURRENT_TIMESTAMP NOT NULL,*/
    response_params      varchar (255)   NULL,
    CHECK (status IN ('S', 'P', 'C', 'F')),
    CONSTRAINT PK_command_queue PRIMARY KEY (command_id)
)
;

/*
 * TABLE: data_capture
 */

CREATE TABLE data_capture(
    data_capture_id    int		AUTO_INCREMENT,
    link_id            int             NOT NULL,
    name               varchar(40)     NOT NULL,
    description        varchar(128)    NULL,
    start_ts           TIMESTAMP       DEFAULT CURRENT_TIMESTAMP NOT NULL,
    end_ts             datetime        NULL,
    CONSTRAINT PK_data_capture PRIMARY KEY (data_capture_id)
)
;

/*
 * TABLE: data_log
 */

CREATE TABLE data_log(
    data_capture_id    int                 NOT NULL,
    data_log_id	       int		   NOT NULL,
    start_ts           datetime            NOT NULL,
    start_us           double precision    DEFAULT 0 NOT NULL,
    end_ts             datetime            NOT NULL,
    end_us             double precision    DEFAULT 0 NOT NULL,
    data               LONGBLOB            NULL
   /* --CONSTRAINT PK_data_log PRIMARY KEY (data_capture_id) */
)
;

/*
 * TABLE: event_log
 */

CREATE TABLE event_log(
    event_id	     int		 AUTO_INCREMENT,
    datetime_ts      TIMESTAMP           DEFAULT CURRENT_TIMESTAMP NOT NULL,
    datetime_us      double precision    DEFAULT 0 NOT NULL,
    host_id          smallint            DEFAULT 0 NOT NULL,
    link_id	     int		 DEFAULT 0 NOT NULL,
    rsm_id	     int		 DEFAULT 0 NOT NULL,
    user_id          int                 DEFAULT 0 NOT NULL,
    command_id	     int                 DEFAULT 0 NOT NULL,
    event_type_id    int                 DEFAULT 0 NOT NULL,
    severity         tinyint             DEFAULT 0 NOT NULL,
    message          varchar(255)        NOT NULL,
    CHECK (severity IN (0,1,2,3)),
    CONSTRAINT PK_event_log PRIMARY KEY (event_id)
)
;

/*
 * TABLE: event_type_lookup
 */

CREATE TABLE event_type_lookup(
	event_type_id	 int			NOT NULL,
    name             varchar(40)    NOT NULL,
    CONSTRAINT PK_event_type_lookup PRIMARY KEY (event_type_id)
)
;

/*
 * TABLE: device_module_lookup
 */

CREATE TABLE device_module_lookup(
	device_module_id	 int			NOT NULL,
    name                 varchar(40)    NOT NULL,
    device_type 		 int DEFAULT 0	NOT NULL,
    CONSTRAINT PK_device_module_lookup PRIMARY KEY (device_module_id)
)
;

/*
 * TABLE: host
 */

CREATE TABLE host(
    host_id    smallint       NOT NULL,
    name       varchar(40)    NOT NULL,
    CONSTRAINT PK_host PRIMARY KEY (host_id)
)
;

/*
 * TABLE: handshaking
 */

CREATE TABLE handshaking_lookup(
    handshaking    char       NOT NULL,
    name       varchar(40)    NOT NULL
)
;

/*
 * TABLE: host_pages
 */

CREATE TABLE host_pages(
    page_id				int            NOT NULL,
    page_name           varchar(50)    NULL,
    page_active         bit            NOT NULL,
    last_modified_ts    datetime       NOT NULL,
    page_description    TEXT    NULL,
    CONSTRAINT PK_host_pages PRIMARY KEY (page_id)
)
;

/*
 * TABLE: host_pages_acl
 */

CREATE TABLE host_pages_acl(
	host_page_acl_id int		 AUTO_INCREMENT,
    group_id    	 int       	 NOT NULL,
    page_id		     int         NOT NULL,
    acl_create_ts    datetime    NOT NULL,
    CONSTRAINT PK_host_pages_acl PRIMARY KEY (host_page_acl_id)
)
;

/*
 * TABLE: host_parameters
 */

CREATE TABLE host_parameters(
    host_id             smallint        DEFAULT 0 NOT NULL,
    param_id            smallint        NOT NULL,
    param_name          varchar(120)    NOT NULL,
    param_value         varchar(255)    NULL,
    last_modified_ts    datetime        NOT NULL
)
;

/*
 * TABLE: link
 */

CREATE TABLE link(
    link_id                 		int           NOT NULL,
    host_id				    		int			  NOT NULL,
    clear_port_id           		int           NOT NULL,
    secure_port_id          		int           NOT NULL,
    active_yn               		bit           NULL,
    name                    		varchar(40)   NULL,
    compress_yn             		bit           NULL,
    encrypt_yn              		bit           NULL,
    send_data_timeout       		int           DEFAULT 1    NOT NULL,
    recv_data_timeout       		int           DEFAULT 1    NOT NULL,
    comp_keep_alive_timeout 		int           DEFAULT 0    NOT NULL,
    max_payload_size        		int           DEFAULT 1024 NOT NULL,
    link_type				int	      DEFAULT 0    NOT NULL,
    dict_minutes_update 		int 	      DEFAULT 60   NOT NULL,
	dict_minutes_transfer_update 	int 	      DEFAULT 30   NOT NULL,
	clear_master_dict_minutes 	int 	      DEFAULT 90   NOT NULL,
	minimum_ratio_before_switch 	NUMERIC(6, 5) DEFAULT 0.1  NOT NULL,
	root1_dict_stamp 		int 	      DEFAULT 0    NOT NULL,
	root2_dict_stamp 		int 	      DEFAULT 0    NOT NULL,
    last_modified_ts	    		TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    conservative_mode			bit	      DEFAULT 1    NOT NULL,
    max_control_pkt_size		int	      DEFAULT 512  NOT NULL,
    control_packet_delay		int	      DEFAULT 200  NOT NULL,
    rsm_firmware_packet_size		int	      DEFAULT 256  NOT NULL,
    rmd_firmware_packet_size		int	      DEFAULT 512  NOT NULL,
	redundant_link_id				int			  DEFAULT -1   NOT NULL,
    dr_mode							int			  DEFAULT -1   NOT NULL,
    fail_over_port					int			  DEFAULT -1   NOT NULL,
    CHECK (max_payload_size BETWEEN 1 AND 65535),
    CONSTRAINT PK_link PRIMARY KEY (link_id)
)
;
/*
 * TABLE: redundant_link
 */
 
CREATE TABLE redundant_link (
	link_id							int			NOT NULL,
	name							varchar(40)	NULL,
	master_link_id					int			NULL,
	CONSTRAINT PK_redundant_link PRIMARY KEY (link_id)
)
;
/*
 * TABLE: location
 */

CREATE TABLE location(
    location_id    int            AUTO_INCREMENT,
    name           varchar(40)    NULL,
    address1       varchar(60)    NULL,
    address2       varchar(50)    NULL,
    city           varchar(50)    NULL,
    state          varchar(30)    NULL,
    zipcode        varchar(10)    NULL,
    CONSTRAINT PK_location PRIMARY KEY (location_id)
)
;

/*
 * The following insert must be made here and is needed.
 */
INSERT INTO location (location_id, name) VALUES (0, 'n/a');

update location set location_id = 0;

/*
 * TABLE: parity_lookup
 */

CREATE TABLE parity_lookup(
    parity_id    varchar(1)     NOT NULL,
    name         varchar(10)    NOT NULL,
    CONSTRAINT PK_parity_lookup PRIMARY KEY (parity_id)
)
;

/*
 * TABLE: password_history
 */
CREATE TABLE password_history (
	password_id			int			AUTO_INCREMENT,
	user_id				int			NOT NULL,
	password			varchar(50)		NOT NULL,
	password_ts			datetime		NOT NULL,
	CONSTRAINT PK_password_history PRIMARY KEY(password_id)
);

/*
 * TABLE: password_security
 */
CREATE TABLE password_security (
	policy_id			int			AUTO_INCREMENT,
	password_history_amt		int			NOT NULL,
	min_password_age		int			NOT NULL,
	max_password_age		int			NOT NULL,
	min_password_len		int			NOT NULL,
	alpha_numeric_char		bit			NOT NULL,
	special_char			bit			NOT NULL,
	CONSTRAINT PK_password_security PRIMARY KEY(policy_id)
);

/*
 * TABLE: port
 */

CREATE TABLE port(
	port_id		 int		AUTO_INCREMENT,
    host_id              smallint        DEFAULT 0 NOT NULL,
    os_port_name         varchar(40)     NOT NULL,
    description          varchar(128)    NULL,
    baudrate             int             DEFAULT 0 NULL,
    databits		 int             DEFAULT 0 NULL,
    parity_id            varchar(1)      NULL,
    stopbits		 tinyint         NULL,
    handshaking		 varchar(1)	 DEFAULT 'N' NULL,
    port_type            int             DEFAULT 0 NOT NULL,
    host_name            varchar(100)    NULL,
    tcp_port             int             NULL,
    reconnect_timeout	 int             DEFAULT 0 NULL,
    reconnect_retries  int             	 DEFAULT 10 NULL,
    preamble			 int			 DEFAULT 0 NOT NULL,
    postamble			 int			 DEFAULT 0 NOT NULL,
    map_cd_to_dtr		 bit			 DEFAULT 0 NOT NULL,
    data_hold_back		 bit			 DEFAULT 0 NOT NULL,
    hold_ms				 int			 DEFAULT 0 NOT NULL,
	is_listener			 bit			 DEFAULT 0 NULL,
    CHECK (databits IN (7,8)),
    CHECK (stopbits IN (0,1)),
    CONSTRAINT PK_port PRIMARY KEY (port_id)
)
;

/*
 * TABLE: rmd_line
 */

/* answer_state:	'A'=RMD will answer if ring, 'B'=line is busied out, 'R'=line will ring but RMD will not answer */
/* phone_number:	optional phone number, user can enter, but it's not used by the system to validate anything */
/* init_string:		Modem initialization string, sent to modem to initialize */
/* answer_string:	Modem string sent to answer the line */
/* onhook_string:	Modem string sent to hang up (on hook) */
/* offhook_init_string: Modem string sent to go off hook, but not answer (busy) */
/* ring_string:		String from Modem indicating the line is ringing */
/* connect_string:	String from Modem indicating the modem has connected successfully */
/* disconnect_string: String from Modem indicating the modem has disconnected */
/* ok_string:		String from Modem indicating that it has accepted the command */
/* error_string:	String from Modem indicating that it has not accepted the command */

CREATE TABLE rmd_line(
    rsm_id              int           NOT NULL,
    line_number         tinyint       DEFAULT 0 NOT NULL,
	phone_number        varchar(20)   NULL,
    ctl_baudrate        int           DEFAULT 0 NULL,
    ctl_databits		int           DEFAULT 0 NULL,
    ctl_parity_id       varchar(1)    NULL,
    ctl_stopbits        tinyint       NULL,
    modem_baudrate      int           DEFAULT 0 NULL,
    modem_databits	    int           DEFAULT 0 NULL,
    modem_parity_id     varchar(1)    NULL,
    modem_stopbits      tinyint       NULL,

	init_string         varchar(40)  DEFAULT 'ATZH0' NULL,
    answer_string       varchar(20)  DEFAULT 'ATA' NULL,
    onhook_string       varchar(20)  DEFAULT 'ATH0' NULL,
    offhook_init_string varchar(20)  DEFAULT 'ATH1' NULL,
    ring_string         varchar(20)  DEFAULT 'RING' NULL,
    connect_string      varchar(20)  DEFAULT 'CONNECT' NULL,
    disconnect_string   varchar(20)  DEFAULT 'DISCONNECT' NULL,
    ok_string           varchar(20)  DEFAULT 'OK' NULL,
    error_string        varchar(20)  DEFAULT 'ERROR' NULL,

/*	--CHECK (answer_state IN ('A', 'B', 'R')), */
    CHECK (modem_databits IN (7,8)),
    CHECK (ctl_databits IN (7,8)),
    CONSTRAINT PK_rmd_line PRIMARY KEY (rsm_id,line_number)
)
;

/*
 * TABLE: rmd_schedule - list of daily time periods for RMD access.  All time stamps are from the host perspective.
 * No timeperiods may overlap for a given RMD.  rsm_i = -1 defines the default time schedule for all RMD's.  rsm_id = anything
 * else to define an overridden time schedule for a specific RMD.
 */

 /* rsm_id:			-1=global default, or 0+ = specific to one RMD */
 /* start_hour:		starting hour, 0-23 */
 /* start_minute:	starting minute, 0-59 */
 /* answer_state:	'A'=RMD will answer if ring, 'B'=line is busied out, 'R'=line will ring but RMD will not answer */

CREATE TABLE rmd_schedule(
    rsm_id              int           NOT NULL,
    line_number			tinyint		  NOT NULL,
    start_hour          tinyint       DEFAULT 0 NULL,
    start_minute        tinyint       DEFAULT 0 NULL,
    answer_state		varchar(1)	  DEFAULT 'R' NULL,
    CHECK (start_hour BETWEEN 0 AND 23),
    CHECK (start_minute BETWEEN 0 AND 59),
    CHECK (answer_state IN ('A', 'B', 'R'))
)
;


/*
 * TABLE: rsm
 */

 /* rmd_idle_timeout:	After log in, amount of idle time (in seconds) before RMD disconnects the user */
 /* rmd_login_retries:	Number of login retries */
 /* rmd_login_delay:	Number seconds the RMD waits after unsuccessful login, before prompting again */
 /* rmd_login_timeout:	Number of seconds the user has to complete a successful login. RMD will disconnect an unauthenticated call if this timeout passes */

CREATE TABLE rsm(
    rsm_id               int         NOT NULL,
    name				 varchar(40) NULL,
    link_id              int         NOT NULL,
    location_id          int         DEFAULT 0 NOT NULL,
    active_yn            bit         NULL,
    network_address      smallint    NOT NULL,
    serial_number        char(16)    NOT NULL,
    rsm_model            int         DEFAULT 0 NOT NULL,
    bank0_firm_maj_ver   smallint    NULL,
    bank0_firm_min_ver   smallint    NULL,
    bank0_firm_pat_ver   smallint    NULL,
    bank1_firm_maj_ver   smallint    NULL,
    bank1_firm_min_ver   smallint    NULL,
    bank1_firm_pat_ver   smallint    NULL,
    bank0_rmd_maj_ver    smallint    NULL,
    bank0_rmd_min_ver    smallint    NULL,
    bank0_rmd_pat_ver    smallint    NULL,
    bank1_rmd_maj_ver    smallint    NULL,
    bank1_rmd_min_ver    smallint    NULL,
    bank1_rmd_pat_ver    smallint    NULL,
    rmd_serial_number    char(16)    DEFAULT 0 NULL,
    rmd_model            int         DEFAULT -1 NULL,
    rmd_idle_timeout	 int         DEFAULT 200 NULL,
    rmd_login_retries    int         DEFAULT 3 NULL,
    rmd_login_delay      int         DEFAULT 15 NULL,
    rmd_login_timeout    int         DEFAULT 90 NULL,
	last_dict_stamp      int         DEFAULT 0 NULL,

    CHECK (network_address > 0),
    CONSTRAINT PK_rsm PRIMARY KEY (rsm_id)
)
;

/*
 * TABLE: invalid_rsm
 *
 * Some columns are not used when the device comes on from a pong responce but others may be from
 * an issue related to authentication for which we do not want to loose the information.
 */
 CREATE TABLE invalid_rsm(
    rsm_id               int         NULL,
    name				 varchar(40) NULL,
 	link_id				 int		 NOT NULL,
 	host_id				 int		 NOT NULL,
 	network_address		 smallint	 NOT NULL,
 	discovery_ts		 TIMESTAMP	 DEFAULT CURRENT_TIMESTAMP NULL,
    location_id          int         NULL,
    serial_number        char(16)    NULL,
    rsm_firmware         char(8)     NULL,
    rmd_serial_number    char(16)    DEFAULT 0 NULL,
    rmd_idle_timeout	 int         DEFAULT 200 NULL,
    rmd_login_retries    int         DEFAULT 3 NULL,
    rmd_login_delay      int         DEFAULT 15 NULL,
    rmd_login_timeout    int         DEFAULT 90 NULL
 )
 ;

/*
 * This table is used to move a RMD line when the RSM has been placed into the invalids list.
 */
CREATE TABLE rmd_line_invalid(
    rsm_id              int           NOT NULL,
    line_number         tinyint       DEFAULT 0 NOT NULL,
	phone_number        varchar(20)   NULL,
    ctl_baudrate        int           DEFAULT 0 NULL,
    ctl_databits		int           DEFAULT 0 NULL,
    ctl_parity_id       varchar(1)    NULL,
    ctl_stopbits        tinyint       NULL,
    modem_baudrate      int           DEFAULT 0 NULL,
    modem_databits	    int           DEFAULT 0 NULL,
    modem_parity_id     varchar(1)    NULL,
    modem_stopbits      tinyint       NULL,

	init_string         varchar(40)  DEFAULT 'ATZH0' NULL,
    answer_string       varchar(20)  DEFAULT 'ATA' NULL,
    onhook_string       varchar(20)  DEFAULT 'ATH0' NULL,
    offhook_init_string varchar(20)  DEFAULT 'ATH1' NULL,
    ring_string         varchar(20)  DEFAULT 'RING' NULL,
    connect_string      varchar(20)  DEFAULT 'CONNECT' NULL,
    disconnect_string   varchar(20)  DEFAULT 'DISCONNECT' NULL,
    ok_string           varchar(20)  DEFAULT 'OK' NULL,
    error_string        varchar(20)  DEFAULT 'ERROR' NULL
)
;

/*
 * This table is used to move a RMD schedule when the RSM has been placed into the invalids list.
 */
CREATE TABLE rmd_schedule_invalid(
    rsm_id              int           NOT NULL,
    line_number			tinyint		  NOT NULL,
    start_hour          tinyint       DEFAULT 0 NULL,
    start_minute        tinyint       DEFAULT 0 NULL,
    answer_state		varchar(1)	  DEFAULT 'R' NULL
)
;


/*
 * TABLE: sys_compression
 */

CREATE TABLE sys_compression(
    id                int         DEFAULT 0 NOT NULL,
    host_id           smallint    NOT NULL,
    LZW_statistics    TEXT        NOT NULL,
    LZW_counter       int         DEFAULT 0 NULL,
    CHECK (LZW_counter < 65535),
    CONSTRAINT PK_sys_compression PRIMARY KEY (id)
)
;

/*
 * TABLE: sys_default
 */

 /* rmd_idle_timeout:	After log in, amount of idle time (in seconds) before RMD disconnects the user */
 /* rmd_login_retries:	Number of login retries */
 /* rmd_login_delay:	Number seconds the RMD waits after unsuccessful login, before prompting again */
 /* rmd_login_timeout:	Number of seconds the user has to complete a successful login. RMD will disconnect an unauthenticated call if this timeout passes */
 /* rmd_phone_list:		W=use white list, 'B'=use black list, 'N'=use no list */
 /* rmd_init_string:	Modem initialization string, sent to modem to initialize */
 /* rmd_answer_string:	Modem string sent to answer the line */
 /* rmd_onhook_string:	Modem string sent to hang up (on hook) */
 /* rmd_offhook_init_string: Modem string sent to go off hook, but not answer (busy) */
 /* rmd_ring_string:	String from Modem indicating the line is ringing */
 /* rmd_connect_string:	String from Modem indicating the modem has connected successfully */
 /* rmd_disconnect_string: String from Modem indicating the modem has disconnected */
 /* rmd_ok_string:		String from Modem indicating that it has accepted the command */
 /* rmd_error_string:	String from Modem indicating that it has not accepted the command */
 /* rmd_ANI_modem_yn:	True=modem provides ANI data (number the caller called), or False=Not */
 /* rmd_DNIS_modem_yn:	True=modem provides DNIS data (number the caller is calling from), or False=Not */

CREATE TABLE sys_default(
    id                         int           DEFAULT 0 NOT NULL,
    baudrate                   int           DEFAULT 0 NULL,
    port_databits	           int           DEFAULT 8 NULL,
    parity_id                  varchar(1)    NULL,
    port_stopbits              tinyint       NULL,
    link_type                  int           DEFAULT 0 NOT NULL,
    link_send_delay            smallint      DEFAULT 0 NOT NULL,
    link_send_data_timeout     int           DEFAULT 1 NOT NULL,
    link_recv_data_timeout     int           DEFAULT 1 NOT NULL,
    link_max_payload_size      int           DEFAULT 1024 NOT NULL,
    link_session_key_length    smallint      DEFAULT 128 NOT NULL,

	rmd_idle_timeout	 int            DEFAULT 200 NULL,
    rmd_login_retries    int            DEFAULT 3 NULL,
    rmd_login_delay      int            DEFAULT 15 NULL,
    rmd_login_timeout    int            DEFAULT 90 NULL,

    rmd_init_string         varchar(40)  DEFAULT 'ATZH0' NULL,
    rmd_answer_string       varchar(20)  DEFAULT 'ATA' NULL,
    rmd_onhook_string       varchar(20)  DEFAULT 'ATH0' NULL,
    rmd_offhook_init_string varchar(20)  DEFAULT 'ATH1' NULL,
    rmd_ring_string         varchar(20)  DEFAULT 'RING' NULL,
    rmd_connect_string      varchar(20)  DEFAULT 'CONNECT' NULL,
    rmd_disconnect_string   varchar(20)  DEFAULT 'DISCONNECT' NULL,
    rmd_ok_string           varchar(20)  DEFAULT 'OK' NULL,
    rmd_error_string        varchar(20)  DEFAULT 'ERROR' NULL,

	CHECK (link_max_payload_size BETWEEN 1 AND 65535),
    CHECK (port_stopbits IN (0, 1)),
    CHECK (port_databits IN (8)),
    CHECK (link_session_key_length IN (8,16,32,64,128,256,512,1024,2048)),
    CONSTRAINT PK_sys_default PRIMARY KEY (id)
)
;

/*
 * TABLE: sys_security
 */

CREATE TABLE sys_security(
    host_id            int              NOT NULL,
    key_string         varchar(216)     NULL,
    reboot_password    varchar(44)      NOT NULL,
    CONSTRAINT PK_sys_security PRIMARY KEY (host_id)
)
;

/*
 * TABLE: user_groups
 */

CREATE TABLE user_groups(
	group_id	int		AUTO_INCREMENT,
    name                varchar(40)     NOT NULL,
    description         varchar(128)    NULL,
    disabled_yn         bit             NULL,
    deleted_yn          bit             NULL,
    create_ts           TIMESTAMP       DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_modified_ts    TIMESTAMP       NULL, /*DEFAULT CURRENT_TIMESTAMP NOT NULL,*/
    disabled_ts         datetime        NULL,
    deleted_ts          datetime        NULL,
    CONSTRAINT PK_user_groups PRIMARY KEY (group_id)
)
;

/*
 * TABLE: users_user_group_rel
 */

CREATE TABLE users_user_group_rel(
    group_id       	int         NOT NULL,
    user_id             int         NOT NULL,
    create_ts           TIMESTAMP   DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_modified_ts    TIMESTAMP   NULL, /*DEFAULT CURRENT_TIMESTAMP NOT NULL, */
    CONSTRAINT PK_users_user_group_rel PRIMARY KEY (group_id,user_id)
)
;

/*
 * TABLE: users
 */

/* rmd_login_allowed_yn:	must be true in order for a user to log in on a modemdefender */

CREATE TABLE users(
	user_id	           int		AUTO_INCREMENT,
    login                  varchar(40)    NOT NULL,
    password               varchar(64)    NOT NULL,
    first_name             varchar(50)    NOT NULL,
    last_name              varchar(50)    NOT NULL,
    deleted_yn             bit            NULL,
    disabled_yn            bit            NULL,
    rmd_login_allowed_yn   bit            DEFAULT 0 NOT NULL,
    create_ts              TIMESTAMP      DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_modified_ts       TIMESTAMP      NULL, /*DEFAULT CURRENT_TIMESTAMP NOT NULL,*/
    delete_ts              datetime       NULL,
    disabled_ts            datetime       NULL,
    pw_expiration_ts       datetime       NOT NULL,
    forced_user_signoff    bit            NOT NULL,
    CONSTRAINT PK_users PRIMARY KEY (user_id)
)
;