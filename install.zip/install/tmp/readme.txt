1xx - Table creation scripts for different DBMS
2   - Load Defaults script with Unicode symbols
3   - Ex- Alter and Indexes scripts, common.
 